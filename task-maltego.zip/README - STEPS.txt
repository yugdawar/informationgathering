To effectively showcase how to perform email investigation and information gathering using Maltego on Kali Linux or Parrot OS, follow these refined steps:

1. **Prepare Your Environment:**
   - Ensure you are using Kali Linux or Parrot OS, as Maltego is typically pre-installed in these distributions. If not installed, you can download it from the repository.

2. **Launch Maltego:**
   - Open a terminal and type `maltego`. If Maltego is not already installed, follow the prompts to download and install it from the repository.

3. **Select the Machine and Configuration:**
   - In Maltego, navigate to the Machines tab and select the appropriate configuration. Click on "Run Machine" and locate the option related to URL information gathering.

4. **Input the Target URL:**
   - Paste the URL of the website or email domain for which you want to gather information. This step initiates the scanning and information retrieval process.

5. **Run the Analysis:**
   - Click on "Run" to start the analysis. Maltego will proceed to gather all possible domain IP addresses, host information, and additional details as demonstrated in the accompanying video.

By following these steps, you will effectively replicate the email investigation and information gathering process using Maltego, showcasing the comprehensive capabilities for domain and host data retrieval.